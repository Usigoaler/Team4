import java.time.LocalDate;

public class BookStoreMain {
    public static void main(String[] args) {
        //create a bookStore object and instantiate
BookStore bookStore = new BookStore();
        //create a customer who can then buy books
Customer customer1 = new Customer("Dom","+897321123","DomT@gmail.com");
        //customer1 places an order to purchase a book
Stock book1 = new Stock("java Program","Joyce",19.99);
        //placing the order ****

Order order1 = new Order(customer1, book1);
        //determine the shipping date
LocalDate shipDate1 = LocalDate.of(2022,11,2);

        //calculate the shipping cost to send the order

Shipping shipOrder1 = new Shipping(order1,shipDate1);
double shipCost1 = shipOrder1.calcShipCost(true);

        //create an invoice ****

Invoice invoice1 = new Invoice("JAVA009",book1,shipOrder1);
        //add the invoices to a list so that we can search for an invoice ****
double cost1 = invoice1.invoice();
bookStore.getInvoices().add(invoice1);
        System.out.println(bookStore.pilingUpOfOrders());
        //customer1 ***end***









        //a repeat with another customer, order, etc...

Customer customer2 = new Customer("Paul","19132483","PaulW@gmail.com");
        //determine the shipping date

Stock book2 = new Stock("Learn to Drive","DomT",24.99);
Order order2 = new Order(customer2,book2);
         // determine the shipping date
        LocalDate shipDate2 = LocalDate.of(2022,11,04);

        //calculate the shipping cost to send the order
Shipping shipOrder2 = new Shipping(order2,shipDate2);
double shipCost2 = shipOrder2.calcShipCost(true);

        //create an invoice
        Invoice invoice2 = new Invoice("HTD009",book2,shipOrder2);
        //cost the invoice for invoice object
        double cost2 = invoice2.invoice();



        //add the invoices to a list so that we can search for an invoice
bookStore.getInvoices().add(invoice2);

        //search for order
        Invoice Invoicefound = bookStore.searchOrder("HTD009");

    }
}

