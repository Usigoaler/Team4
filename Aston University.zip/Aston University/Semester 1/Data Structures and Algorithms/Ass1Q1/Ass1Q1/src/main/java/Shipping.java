//import to be included

import java.time.LocalDate;
public class Shipping {
    Order order;
    LocalDate shipDate;

    public double shipCost;
    public static int countUrgent;

    public Shipping(Order order, LocalDate shipDate){
        //complete the constructor
        this.order = order;
        this.shipDate = shipDate;
    }
    public Order getOrder(){
        return  order;
    }
    public  LocalDate getShipDate() {
        return shipDate;

    }

    public void setShipCost(double shipCost) {
        this.shipCost = shipCost;
    }
    public double calcShipCost(boolean isUrgent) {
        if (isUrgent) {
            setShipCost(5.45);
            countUrgent++;

        }
        else
            setShipCost(3.95);
        return shipCost;
    }


    public double getShipCost() {
        return shipCost ;
    }
}