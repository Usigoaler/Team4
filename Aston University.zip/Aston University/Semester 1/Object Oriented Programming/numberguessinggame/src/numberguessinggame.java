//Import statement for scanner class
import java.util.Scanner;

//Import statement for random class
import java.util.Random;

public class numberguessinggame {
    public static void main(String[] args) {

        //Random class declaration
        Random random = new Random();

        //Scanner class declaration
        Scanner scanner = new Scanner(System.in);

        //The random number will only be between 1 and 50
        //Random class gives a range of number from 0-0.9 therefore we multiply by the number we want then +1 so the
        //Number is above 0
        //The system counts from 0 therefore to make the system count from 1 we must add a '+1'
        int number = random.nextInt(50) + 1;

        //Created character variable
        char choice;

        //Created counter variable to count how many tries it took to get to the correct number
        int counter = 0;

        do {
            //While the 'while' loop is true the loop will continue to repeat until the correct number is guessed
            while (true) {

                //The console window will display the message 'Enter your guess (1-50)'
                System.out.println("Enter your guess (1-50)");

                //The scanner is created for so the system can scan the guessed number
                int guess = scanner.nextInt();

                //After every guess the counter will increase by 1
                counter++;

                //Checks to see if the guessed number is the same as the random number
                if (guess == number) {

                    //If the guessed number is the same as the random number the system will print 'Correct!'
                    System.out.println("Correct!\nIt took you " + counter + " guesses");

                    //The loop will break here because the condition is now true
                    break;
                }
                //If the guessed number is lower than the random number the system will print 'Higher'
                else if (guess < number) {
                    System.out.println("HIGHER");
                }
                //If the guessed number is higher than the random number the system will print 'lower'
                else {
                    System.out.println("LOWER");
                }
            }
            //Once the number has been correctly guessed the system will ask the user whether they want to start again
            //Or end the game
            System.out.println("Do you want to start again? Enter Y/N");

            //Scans for next character input
            //charAt(0) function returns the first character in that string.
            choice = scanner.next().charAt(0);
        }
            //Both lower case and upper case 'Y' will be accepted by the program
            while (choice == 'Y' | choice == 'y');
    }

}