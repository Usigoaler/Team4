import java.util.Scanner;
public class testing1 {

    public static void main(String[] args){

            Scanner kin = new Scanner(System.in);

            int secretNumber = 55; // Always 55

            int guessedNumber = 0;

            int attempts = 0;

            int maxAttempts = 5;

            while(!(secretNumber == guessedNumber) || attempts < maxAttempts && attempts > 0){

                System.out.println("Guess a number between 0 and 100");

                guessedNumber = kin.nextInt();

                if(guessedNumber == secretNumber){

                    System.out.println("Congratulations you have won!");

                }

                else if(guessedNumber > secretNumber){

                    System.out.println("Try smaller...");

                }

                else if(guessedNumber <= -1){

                    System.out.println("Error: guess needs to be within 0 and 100");

                }

                else if(guessedNumber > 100){

                    System.out.println("Error: guess needs to be within 0 and 100");

                }

                if(guessedNumber < secretNumber){

                    System.out.println("Try larger...");

                }

                else if(attempts == maxAttempts){

                    System.out.println("Better luck next time...");

                }

                else {

                    System.out.println("Unknown error occurred.");

                    break;

                }

            }

        }

    }

