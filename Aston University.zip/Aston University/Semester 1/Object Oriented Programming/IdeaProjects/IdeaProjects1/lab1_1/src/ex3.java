package aston.cs3ios.lab1;
import java.util.Scanner;
public class ex3 {

    public static void main(String[] args) {
        Scanner kin = new Scanner(System.in);

        System.out.println("hi, what can i do for you today?");
        System.out.println(kin.nextLine() + "? It sounds great!");
        System.out.println("please wait.....");

    }
}