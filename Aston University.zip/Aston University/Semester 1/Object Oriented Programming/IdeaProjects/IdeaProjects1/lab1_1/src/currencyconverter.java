import java.util.Scanner;
public class currencyconverter {
    public static void main(String[] args){

        System system = null;
        Scanner scanner = new Scanner (system.in);
        system.out.println("GBP to USD converter. Enter GBP Amount");
        int exchange = scanner.nextInt();
        switch (exchange){

        }
        system.out.println("confirm GBP amount");
        double pound = scanner.nextDouble();

        if (pound>=0) {
            System.out.println (pound + "£ is " + pound*1.37 + "USD");
        }

    }
}
