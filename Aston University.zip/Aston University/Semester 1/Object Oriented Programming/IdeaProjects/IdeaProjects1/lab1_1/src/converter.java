
    import javax.swing.*;

    class gbptousd {
        public static void main(String[] args) {
            //... Declarations.
            String input;
            double gbPounds;
            double usDollars;

            //... Input.
            input = JOptionPane.showInputDialog(null, "Enter British pounds");
            gbPounds = Double.parseDouble(input);

            //... Computation.
            usDollars = 2.0899 * gbPounds;

            //... Output.
            JOptionPane.showMessageDialog(null, usDollars + " US Dollars");
        }
    }

