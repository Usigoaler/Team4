
public class lesson1 {

    public static void main(String[] args){

        int num1 =2;
        int num2 =3;
        int num3 =4;
        int result = 2 + (3 * 5);

        System.out.println(result);

    }
}
