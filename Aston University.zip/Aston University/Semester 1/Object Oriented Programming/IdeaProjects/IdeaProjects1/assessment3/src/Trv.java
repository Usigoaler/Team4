public class Trv {
    String trvnum1;
    String trvnum2;
    String trvnum3;
    String trvnum4;

    double temp1;
    double temp2;
    double temp3;
    double temp4;

    int heatlevel1;
    int heatlevel2;
    int heatlevel3;
    int heatlevel4;


    public void setTrvnum1(String trvnum) {
        this.trvnum1 = trvnum;
    }

    public String getTrvnum1() {
        return trvnum1;
    }

    public void setTemp1(double temp) {
        this.temp1 = temp;
    }

    public double getTemp1() {
        return temp1;
    }

    public void setTrvnum2(String trvnum) {
        this.trvnum2 = trvnum;
    }

    public String getTrvnum2() {
        return trvnum2;
    }

    public void setTemp2(double temp) {
        this.temp2 = temp;
    }

    public double getTemp2() {
        return temp2;
    }

    public void setTrvnum3(String trvnum) {
        this.trvnum3 = trvnum;
    }

    public String getTrvnum3() {
        return trvnum3;
    }

    public void setTemp3(double temp) {
        this.temp3 = temp;
    }

    public double getTemp3() {
        return temp3;
    }

    public void setTrvnum4(String trvnum) {
        this.trvnum4 = trvnum;
    }

    public String getTrvnum4() {
        return trvnum4;
    }

    public void setTemp4(double temp) {
        this.temp4 = temp;
    }

    public double getTemp4() {
        return temp4;
    }

    public void setHeatlevel1(int heatlevel) {
        this.heatlevel1 = heatlevel;
    }

    public int getHeatlevel1() {
        return heatlevel1;
    }

    public void setHeatlevel2(int heatlevel) {
        this.heatlevel2 = heatlevel;
    }

    public int getHeatlevel2() {
        return heatlevel2;
    }

    public void setHeatlevel3(int heatlevel) {
        this.heatlevel3 = heatlevel;
    }

    public int getHeatlevel3() {
        return heatlevel3;
    }

    public void setHeatlevel4(int heatlevel) {
        this.heatlevel4 = heatlevel;
    }

    public int getHeatlevel4() {
        return heatlevel4;
    }
}
