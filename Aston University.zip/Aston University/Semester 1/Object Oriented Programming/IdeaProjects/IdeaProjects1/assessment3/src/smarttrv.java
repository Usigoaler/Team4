import java.util.Scanner;
public class smarttrv {
    public static void main(String[] args){

        Trv trv = new Trv();
        Scanner scanner = new Scanner(System.in);

        trv.setTrvnum1("Trv1");
        trv.setTemp1(18);

        trv.setTrvnum2("Trv2");
        trv.setTemp2(18);

        trv.setTrvnum3("Trv3");
        trv.setTemp3(18);

        trv.setTrvnum4("Trv4");
        trv.setTemp4(18);

        trv.setHeatlevel1(0);
        trv.setHeatlevel2(0);
        trv.setHeatlevel3(0);
        trv.setHeatlevel4(0);

        System.out.println("What would you like to do?\n");
        System.out.println(" Set Target Temprature:1 \n Set Heat level:2 \n Retrieve current temperature:3 \n Retrieve battery level:4 \n Retrieve TRV ID:5 \n Turn off TRV:6 \n TRV to app connection:7");

        int option = scanner.nextInt();
        if (option == 1) {
            System.out.println("What would you like to set the TRV temperature to?");
            double newtemp = scanner.nextDouble();
            System.out.println("The TRV temperature has been set to " + newtemp + " Degrees");
            trv.setTemp1(newtemp);
            trv.setTemp2(newtemp);
            trv.setTemp3(newtemp);
            trv.setTemp4(newtemp);
            System.out.println(trv.getTrvnum1() + " " + trv.getTemp1() + " Degrees\n" + trv.getTrvnum2() + " " + trv.getTemp2() + " Degrees\n" + (trv.getTrvnum3() + " " + trv.getTemp3() + " Degrees\n" + trv.getTrvnum4() + " " + trv.getTemp4() + " Degrees\n"));
        }
        if (option == 2){
            System.out.println("What would you like to set the heat level to?");
            int newheatlevel = scanner.nextInt();
            System.out.println("The TRV heat level has been set to level " + newheatlevel);
            trv.setHeatlevel1(newheatlevel);
            trv.setHeatlevel2(newheatlevel);
            trv.setHeatlevel3(newheatlevel);
            trv.setHeatlevel4(newheatlevel);
            System.out.println(trv.getTrvnum1() + " Heat level " + trv.getHeatlevel1() + "\n" + trv.getTrvnum2() + " Heat level " + trv.getHeatlevel2() + "\n" + trv.getTrvnum3() + " Heat level " + trv.getHeatlevel3() + "\n" + trv.getTrvnum4() + " Heat level " + trv.getHeatlevel4());
        }
        if (option == 3){
            System.out.println("The current temperature is set to");
            System.out.println(trv.getTrvnum1() + " " + trv.getTemp1() + " Degrees ->" + " Heat level " + trv.getHeatlevel1());
            System.out.println(trv.getTrvnum2() + " " + trv.getTemp2() + " Degrees ->" + " Heat level " + trv.getHeatlevel2());
            System.out.println(trv.getTrvnum3() + " " + trv.getTemp3() + " Degrees ->" + " Heat level " + trv.getHeatlevel3());
            System.out.println(trv.getTrvnum4() + " " + trv.getTemp4() + " Degrees ->" + " Heat level " + trv.getHeatlevel4() + "\n");
        }
        if (option == 4) {
            System.out.println("Battery is full");
        }
        if (option == 6){
            System.out.println(trv.getTrvnum1() + " Shutting down " + trv.getTrvnum2() + " Shutting down " + trv.getTrvnum3() + " Shutting down" + trv.getTrvnum4() + " Shutting down");
        }
        if (option == 7){
           System.out.println("Which TRV would you like to check for connection? \n enter 1-4");
           int connection = scanner.nextInt();

           if (connection == 1){
               System.out.println("Connection succesfull");
           }
            if (connection == 2){
                System.out.println("Connection succesfull");
            }
            if (connection == 3){
                System.out.println("Connection succesfull");
            }
            if (connection == 4){
                System.out.println("Connection succesfull");
            }
        }
        if (option == 5){
            System.out.println("Select TRV: 1-4");

            int ID = scanner.nextInt();
            if (ID == 1) {
                System.out.println("TRV 1 ID: 1.1");
            }
            if (ID == 2) {
                System.out.println("TRV 2 ID: 1.2");
            }
            if (ID == 3) {
                System.out.println("TRV 3 ID: 1.3");
            }
            if (ID == 4) {
                System.out.println("TRV 4 ID: 1.4");

            }

        }
    }
}



