import java.util.Scanner;
public class currencycoverter2 {
    public static void main (String[] args){

        Scanner scanner = new Scanner(System.in);

        System.out.println("enter the following details");

        System.out.println("Name");
        String Name = scanner.next();

        System.out.println("Programme of Study");
        String Programme = scanner.next();

        System.out.println("Age");
        int age = scanner.nextInt();

        System.out.println("your weekly expenditure in GBP");
        int expenses = scanner.nextInt();

            System.out.println(Name+ " "+ Programme + " "+ age + " "+ expenses*1.09);
    }
}
