import java.util.Scanner;
public class borrowingbook {
    public static void main(String[] args) {

        System.out.println("Are you a Student");
        System.out.println("Answer with yes or no?");

        String answer = "yes";

        Scanner scanner = new Scanner(System.in);

        String word = scanner.next();


        if (answer.compareTo(word)==0){
            System.out.println("How many books requested?");

            int books = scanner.nextInt();
            if (books<=3) {
                System.out.println("You qualify to borrow the book");
            }
            else {
                System.out.println("Sorry, your request cannot be fulfilled");
            }
        }

        else {
            System.out.println("You are not a student");

        }
    }
}

